## Development Progress

- [ ] New architecture
  
   - [x] Activities: Main & Prefs
  
   - [ ] Fragments
     
      - [x] Main: Explore, Latest, Installed
     
      - [x] Prefs: Personalisation, Updates, Repositories, Other
     
      - [ ] Sub: App, AddRepo, Search
  
   - [ ] Using multi-sources in MainFragments
  
   - [ ] 

## Progress on 1.0.0

- [ ] Update all button

- [ ] Support multiple mirrors

- [ ] Show changelog of each release

- [ ] Exodus

- [ ] Better management of repositories
  
   - [ ] QR-Code reading
  
   - [ ] Sharing
  
   - [ ] Exporting/importing to a file

- [ ] Theming

## Low Priority/ Future nice-to-haves

- [ ] Move to Compose

- [ ] Material You theming

- [ ] AndroidTV support

- [ ] Apps' block and favorite lists