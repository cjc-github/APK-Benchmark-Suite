# Configurations folder
Here are some dev-targeted configurations(e.g. for integrating app with custom ROMs)
